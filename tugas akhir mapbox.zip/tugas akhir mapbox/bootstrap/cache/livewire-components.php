<?php return array (
  'front' => 'App\\Http\\Livewire\\Front',
  'map-location' => 'App\\Http\\Livewire\\MapLocation',
);